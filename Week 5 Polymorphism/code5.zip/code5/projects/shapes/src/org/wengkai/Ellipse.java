package org.wengkai;

public class Ellipse extends Shape {
    @Override
    public void render() {

    }
}
