package org.wengkai;

public class Square extends Rectangle {

    @Override
    public void render() {
        System.out.println("Square.render()");
    }
}
